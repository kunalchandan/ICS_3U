import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;

public class DuckHunt extends JPanel {

	private ImageIcon imgBackground, imgForeground, imgCursor;
	private Cursor cursor;
	private boolean start;
	private FontMetrics fm;
	private Font f;
	private int score, hits;
	private double accuracy;
	private DecimalFormat df;

	public static void main(String[]args) {

		new DuckHunt();
	}

	public DuckHunt() {
		
		df = new DecimalFormat("#%");
		f = new Font("Neuropol", Font.BOLD, 18);
		fm = getFontMetrics(f);
		
		start = false;
		
		imgBackground = new ImageIcon("images\\background.png");
		imgForeground = new ImageIcon("images\\foreground.png");

		imgCursor = new ImageIcon("images\\cursor.png");

		cursor = Toolkit.getDefaultToolkit().createCustomCursor(imgCursor.getImage(), 
				new Point(imgCursor.getIconWidth() / 2, imgCursor.getIconHeight() / 2), "");

		setLayout(null);
		setCursor(cursor);
		setFocusable(true);
		requestFocus();

		JFrame frame = new JFrame();
		frame.setContentPane(this);
		frame.setTitle("Duck Hunt � Nintendo 1985");
		frame.setSize(imgBackground.getIconWidth(), imgBackground.getIconHeight());
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setFocusable(false);
		frame.setVisible(true);
	}

	public void paintComponent(Graphics g) {

		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		g2.drawImage(imgBackground.getImage(), 0, 0, this);
		g2.drawImage(imgForeground.getImage(), 0, 0, this);
		g2.setFont(f);
		g2.setColor(new Color(128, 208, 16));
		
		if (start)
		{		
			g2.drawString("SCORE:  " + score, 20, getHeight() - 25);
			g2.drawString("HITS:  " + hits, 250, 
					getHeight() - 25);
			g2.drawString("ACCURACY:  " + df.format(accuracy), 425, getHeight() - 25);
		}
		else
		{
			g2.drawString("CLICK SPACEBAR TO BEGIN", 
					getWidth() / 2 - fm.stringWidth("CLICK SPACEBAR TO BEGIN") / 2,
					getHeight() - 25);
		}
	}
}