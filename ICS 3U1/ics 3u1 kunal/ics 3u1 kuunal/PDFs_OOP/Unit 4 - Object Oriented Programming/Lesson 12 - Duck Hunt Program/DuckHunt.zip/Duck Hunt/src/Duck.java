
public class Duck {

}
