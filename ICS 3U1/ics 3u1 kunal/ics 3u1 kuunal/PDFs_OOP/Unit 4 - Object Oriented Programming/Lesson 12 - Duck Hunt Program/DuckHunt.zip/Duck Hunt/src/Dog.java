
public class Dog {

}
